# Portfolio setup guide

This folder is a complete portfolio website. It is free to host, and only you can edit it.

- **Public site:** `https://YOUR-USERNAME.github.io`. Put this link on your CV and LinkedIn.
- **Your private editor:** `https://YOUR-USERNAME.github.io/admin/`

Do the setup once on a laptop. It takes about 20 minutes.

---

## 1. Create your GitHub account

1. Go to github.com and sign up. Choose a professional username, for example `odinakachi-egeneonu`.
2. Verify your email address.

> Your username becomes part of your website address. Send it to Claude and it will fill in the two settings below for you. If you would rather do it yourself, see step 6.

## 2. Create the website repository

1. Click **+** (top right), then **New repository**.
2. For **Repository name**, type exactly `YOUR-USERNAME.github.io`, using your real username.
3. Choose **Public**, then click **Create repository**.

## 3. Upload the website files

1. On the new repository page, click **uploading an existing file**.
2. Open the unzipped portfolio folder on your laptop. Select **everything inside it** (`index.html`, `project.html`, `404.html`, `robots.txt`, and the `admin`, `assets` and `data` folders), then drag it all into the browser window.
3. Wait for the upload to finish, then click **Commit changes**.

## 4. Turn the website on

1. In the repository, go to **Settings**, then **Pages** (left menu).
2. Under **Build and deployment**, set **Source** to **Deploy from a branch**, set **Branch** to **main** and the folder to **/ (root)**, then click **Save**.
3. After 1–2 minutes, open `https://YOUR-USERNAME.github.io`. Your portfolio is live.

## 5. Set up your private editor

The editor only lets in someone with a key to your GitHub account, which is you.

**Create your key (once):**
1. On GitHub, click your profile photo, then **Settings**, then **Developer settings** (at the bottom of the left menu).
2. Click **Personal access tokens**, then **Fine-grained tokens**, then **Generate new token**.
3. Name it `Portfolio editor`. Under **Expiration**, pick the longest option.
4. Under **Repository access**, choose **Only select repositories**, then pick your `.github.io` repository.
5. Under **Permissions**, then **Repository permissions**, set **Contents** to **Read and write**.
6. Click **Generate token** and copy it. Save it somewhere private, such as your password manager. Never share it.

**Sign in:**
1. Go to `https://YOUR-USERNAME.github.io/admin/`.
2. Choose **Sign in using access token** and paste your key.

## 6. Editing your portfolio

In the editor:

- **My profile:** change your photo, upload your CV, add your GitHub link, and edit your about text, skills and prices.
- **Projects:** open a project to edit it, or click **Add** to create a new one. Upload dashboard screenshots in the **Dashboard screenshot** field.

Click **Save** when you are done. The live site updates in 1–2 minutes. If you don't see the change, refresh the page.

Tips:
- The first project ticked **Featured** becomes the large spotlight on the home page.
- Empty fields are hidden on the site, so leave something blank if you don't have it yet.
- Only write findings and numbers that come from your actual analysis.

**If you set up the editor yourself:** open `admin/config.yml` on GitHub, click the pencil icon, replace `YOUR-GITHUB-USERNAME` (it appears twice) with your username, and commit. Do the same for the `og:image` line in `index.html` and `project.html`, so the preview image shows when you share your link.

## 7. Optional: contact form messages straight to your inbox

Without this step, the contact form opens the visitor's own email app with their message ready to send. To receive messages directly instead:

1. Sign up free at formspree.io and create a form, using your email.
2. Copy the form ID: the short code at the end of the form address, such as `xyzabcd`.
3. In your editor, go to **My profile** and paste it into **Formspree form ID**, then click Save.

## 8. Share it

- Add the link to your CV, under your name next to your email.
- On LinkedIn, add it under **Contact info**, then **Website**, and in your **Featured** section.
- When you share a project, use **Copy link to this project** on its page. Each project has its own link.
